package utils;

import java.util.ArrayList;
import java.util.BitSet;
import java.util.List;

public class SeqVerticalBitList {
	
	private List<Integer> supportSeqID;	
	private BitSet verticalBitVector;
	private List<ArrayList<Integer>> embeddings;
	
	SeqVerticalBitList() {
		supportSeqID = new ArrayList<>();
		verticalBitVector = new BitSet();
		embeddings = new ArrayList<>();
	}
	
	public void setEmbedding(int seqid, int occur) {
		
		verticalBitVector.set(seqid, true);
		int index = supportSeqID.indexOf(seqid);		
		if (index < 0) {
			supportSeqID.add(seqid);
			ArrayList<Integer> newEmbedding = new ArrayList<>();
			newEmbedding.add(occur);
			embeddings.add(newEmbedding);
		} else {
			embeddings.get(index).add(occur);
		}
	}
		
	public boolean isFrequentItem() {		
		return supportSeqID.size() >= GlobalVar.minAbsoluteFrequency;
	}
	
	public List<Integer> getSupportSeqID() {
		return supportSeqID;
	}
	
	public int getSupportSeqIDSize() {
		return supportSeqID.size();
	}
	
	public List<ArrayList<Integer>> getEmbeddings() {
		return embeddings;
	}
	
	public int getEmbeddingsSize() {
		return embeddings.size();
	}
	
	public BitSet getVerticalBitVector() {
		return verticalBitVector;
	}

}
