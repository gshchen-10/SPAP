package utils;

public class PeriodicItem {
	
	public String custId;
	public int item;
	public float meanPeriod;
	public float stdVariance;
	public float probability;
	
	public PeriodicItem(String seqid, int it, float per, float var, float pro) {
		this.custId = seqid;
		this.item = it;
		this.meanPeriod = per;
		this.stdVariance = var;
		this.probability = pro;
	}

}
