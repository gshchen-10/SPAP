package utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FPGrowth {	
	
	Customer customer;
	
	public int minSupportRelative;
	private int transactionCount = 0;
	
	protected Itemsets patterns = null;
	
	final int BUFFERS_SIZE = 2000;	
	private int[] itemsetBuffer = null;
	private FPNode[] fpNodeTempBuffer = null;
	
	private int maxPatternLength = 2;

	public FPGrowth(Customer custom) {
		this.customer = custom;
	}

	public Itemsets itemsetPatternsMining(int databaseSize, int minsupp) {
		
		patterns = new Itemsets();
		this.minSupportRelative = minsupp;
		this.transactionCount = databaseSize;

		final Map<Integer, Integer> mapSupport = getFrequencyOfSingleItems();
		FPTree tree = new FPTree();		
 
		for (int j = 0; j < customer.getCustOrderSeqSize(); j++) {
			List<Integer> transaction = new ArrayList<Integer>();
			for (int k = 0; k < customer.getCustOrderSeq().get(j).getOrdProductsListSize(); k++) {
				int item = customer.getCustOrderSeq().get(j).getOrdProductsList().get(k);
				if (mapSupport.get(item) >= minSupportRelative) {
					transaction.add(item);	
				}				
			}
			Collections.sort(transaction, new Comparator<Integer>() {
				public int compare(Integer item1, Integer item2) {
					int compare = mapSupport.get(item2) - mapSupport.get(item1);
					if (compare == 0) { 
						return (item1 - item2);
					}
					return compare;
				}
			});
			tree.addTransaction(transaction);
		}		
		tree.createHeaderList(mapSupport);
		
		if (tree.headerList.size() > 0) {
			itemsetBuffer = new int[BUFFERS_SIZE];
			fpNodeTempBuffer = new FPNode[BUFFERS_SIZE];			
			fpgrowth(tree, itemsetBuffer, 0, transactionCount, mapSupport);
		}
		return patterns;
	}

	private void fpgrowth(FPTree tree, int[] prefix, int prefixLength, int prefixSupport, Map<Integer, Integer> mapSupport) {
		
		if (prefixLength == maxPatternLength) {
			return;
		}
		
		boolean singlePath = true;
		int position = 0;
		if (tree.root.childs.size() > 1) {
			singlePath = false;
		} else {			
			FPNode currentNode = tree.root.childs.get(0);
			while (true) {
				if (currentNode.childs.size() > 1) {
					singlePath = false;
					break;
				}
				fpNodeTempBuffer[position] = currentNode;				
				position++;
				if (currentNode.childs.size() == 0) {
					break;
				}
				currentNode = currentNode.childs.get(0);
			}
		}
		if (singlePath) {
			savePrefixPath(fpNodeTempBuffer, position, prefix, prefixLength);
		} else {
			for (int i = tree.headerList.size() - 1; i >= 0; i--) {
				Integer item = tree.headerList.get(i);
				int support = mapSupport.get(item);
				prefix[prefixLength] = item;
				int betaSupport = (prefixSupport < support) ? prefixSupport : support;
				saveItemset(prefix, prefixLength + 1, betaSupport);				
				if (prefixLength + 1 < maxPatternLength) {
					List<List<FPNode>> prefixPaths = new ArrayList<List<FPNode>>();
					FPNode path = tree.mapItemNodes.get(item);
					Map<Integer, Integer> mapSupportBeta = new HashMap<Integer, Integer>();					
					while (path != null) {
						if (path.parent.itemID != -1) {
							List<FPNode> prefixPath = new ArrayList<FPNode>();
							prefixPath.add(path);
							int pathCount = path.counter;
							FPNode parent = path.parent;
							while (parent.itemID != -1) {
								prefixPath.add(parent);
								if (mapSupportBeta.get(parent.itemID) == null) {
									mapSupportBeta.put(parent.itemID, pathCount);
								} else {
									mapSupportBeta.put(parent.itemID, mapSupportBeta.get(parent.itemID) + pathCount);
								}
								parent = parent.parent;
							}
							prefixPaths.add(prefixPath);
						}
						path = path.nodeLink;
					}
					FPTree treeBeta = new FPTree();
					for (List<FPNode> prefixPath : prefixPaths) {
						treeBeta.addPrefixPath(prefixPath, mapSupportBeta, minSupportRelative); 
					}
					if (treeBeta.root.childs.size() > 0) {
						treeBeta.createHeaderList(mapSupportBeta);
						fpgrowth(treeBeta, prefix, prefixLength+1, betaSupport, mapSupportBeta);
					}
				}
			}
		}
		
	}

	private void savePrefixPath(FPNode[] fpNodeTempBuffer, int position, int[] prefix, int prefixLength) {

		int support = 0;
		loop : for (long i = 1, max = 1 << position; i < max; i++) {
			int newPrefixLength = prefixLength;
			for (int j = 0; j < position; j++) {
				int isSet = (int) i & (1 << j);
				if (isSet > 0) {
					if (newPrefixLength == maxPatternLength) {
						continue loop;
					}
					
					prefix[newPrefixLength++] = fpNodeTempBuffer[j].itemID;
					support = fpNodeTempBuffer[j].counter;
				}
			}
			saveItemset(prefix, newPrefixLength, support);
		}
	}
	
	private Map<Integer, Integer> getFrequencyOfSingleItems() {
		Map<Integer, Integer> mapSupport = new HashMap<Integer, Integer>();		
		for (int j = 0; j < customer.getCustOrderSeqSize(); j++) {
			for (int k = 0; k < customer.getCustOrderSeq().get(j).getOrdProductsListSize(); k++) {
				int item = customer.getCustOrderSeq().get(j).getOrdProductsList().get(k);
				Integer count = mapSupport.get(item);
				if (count == null) {
					mapSupport.put(item, 1);
				} else {
					mapSupport.put(item, ++count);
				}					
			}
		}			
		return mapSupport;
	}

	private void saveItemset(int [] itemset, int itemsetLength, int support) {

		int[] itemsetArray = new int[itemsetLength];
		System.arraycopy(itemset, 0, itemsetArray, 0, itemsetLength);			
		Arrays.sort(itemsetArray);			
		ItemArray itemsetObj = new ItemArray(itemsetArray);
		itemsetObj.setAbsoluteSupport(support);
		patterns.addItemset(itemsetObj, itemsetLength);
		
	}

}
