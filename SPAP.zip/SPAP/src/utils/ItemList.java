package utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ItemList{

	public final List<Integer> items = new ArrayList<Integer>(); 

	public ItemList(Integer item) {
		addItem(item);
	}

	public ItemList() {
		
	}

	public void addItem(Integer value) {
		items.add(value);
	}

	public int size() {
		return items.size();
	}

	public ItemList cloneItemSetMinusItems(Map<Integer, Set<Integer>> mapSequenceID, double relativeMinsup) {
		ItemList itemset = new ItemList();
		for (Integer item : items) {
			if (mapSequenceID.get(item).size() >= relativeMinsup) {
				itemset.addItem(item);
			}
		}
		return itemset;
	}

	public ItemList cloneItemSet() {
		ItemList itemset = new ItemList();
		itemset.items.addAll(items);
		return itemset;
	}

	public boolean containsAll(ItemList itemset2) {
		
		int i = 0;
		for (Integer item : itemset2.items) {
			boolean found = false;
			while (found == false && i < size()) {
				if (items.get(i).equals(item)) {
					found = true;
				}
				else if (items.get(i) > item) {
					return false;
				}				
				i++; 
			}
			if (!found) {
				return false;
			}
		}
		return true;
	}
	
}
