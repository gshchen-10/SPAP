package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class AssociationRuleGen {
	
	protected Itemsets patterns;	
	public final List<AssocRule> rules = new ArrayList<AssocRule>();

	protected int ruleCount = 0;
	protected int databaseSize = 0; 
	protected double minconf;

	public AssociationRuleGen() {
		
	}
	
	public List<AssocRule> tryToGenRule(Itemsets patterns, int databaseSize, float minConfidence) {
		
		this.minconf = minConfidence;
		return tryToGenRule(patterns, databaseSize);
	}

	private List<AssocRule> tryToGenRule(Itemsets patterns, int databaseSize) {

		this.databaseSize = databaseSize;
		ruleCount = 0;
		this.patterns = patterns;

		for (List<ItemArray> itemsetsSameSize : patterns.getLevels()) {
			Collections.sort(itemsetsSameSize, new Comparator<ItemArray>() {
				@Override
				public int compare(ItemArray o1, ItemArray o2) {
					return ArraysOperation.comparatorItemsetSameSize.compare(o1.getItems(), o2.getItems());
				}
			});
		}

		for (int k = 2; k < patterns.getLevels().size(); k++) {
			for (ItemArray lk : patterns.getLevels().get(k)) {
				List<int[]> H1_for_recursion = new ArrayList<int[]>();
				for (int item : lk.getItems()) {
					int itemsetHm_P_1[] = new int[] {item};	
					if (lk.size() - 1 <= 1) {
						int[] itemset_Lk_minus_hm_P_1 = ArraysOperation.cloneItemSetMinusOneItem(lk.getItems(), item);

						int support = calculateSupport(itemset_Lk_minus_hm_P_1); 
						double supportAsDouble = (double) support;
						double conf = lk.getAbsoluteSupport() / supportAsDouble;
	
						if (conf < minconf || Double.isInfinite(conf)) {
							continue;
						}
						saveRule(itemset_Lk_minus_hm_P_1, support, itemsetHm_P_1, lk.getAbsoluteSupport(), conf);
					}
				}
				appGenrules(k, 1, lk, H1_for_recursion);
			}			
		}

		return rules;
	}

	private void appGenrules(int k, int m, ItemArray lk, List<int[]> Hm) {

		if (k > m + 1) {
			List<int[]> Hm_plus_1_for_recursion = new ArrayList<int[]>();
			List<int[]> Hm_plus_1 = generateCandidateSizeK(Hm);
			for (int[] hm_P_1 : Hm_plus_1) {				
				if (lk.size() - hm_P_1.length <= 1) {
					int[] itemset_Lk_minus_hm_P_1 =  ArraysOperation.cloneItemSetMinusAnItemset(lk.getItems(), hm_P_1);
					int support = calculateSupport(itemset_Lk_minus_hm_P_1); 
					
					double supportAsDouble = (double)support;
					double conf = lk.getAbsoluteSupport() / supportAsDouble;
					if (conf < minconf || Double.isInfinite(conf)) {
						continue;
					}
					saveRule(itemset_Lk_minus_hm_P_1, support, hm_P_1, lk.getAbsoluteSupport(), conf);
				}
				if (k != m+1 && m + hm_P_1.length <= 1) {
					Hm_plus_1_for_recursion.add(hm_P_1);
				}
			}
			appGenrules(k, m + 1, lk, Hm_plus_1_for_recursion);
		}
	}

	private int calculateSupport(int[] itemset) {
		
		List<ItemArray> patternsSameSize = patterns.getLevels().get(itemset.length);
        int first = 0;
        int last = patternsSameSize.size() - 1;
       
        while (first <= last) {
        	int middle = (first + last) >> 1;
        	int[] itemsetMiddle = patternsSameSize.get(middle).getItems();
        	int comparison = ArraysOperation.comparatorItemsetSameSize.compare(itemset, itemsetMiddle);
            if (comparison  > 0 ) {
            	first = middle + 1;
            } else if (comparison < 0 ) {
            	last = middle - 1;
            } else {
            	return patternsSameSize.get(middle).getAbsoluteSupport();
            }
        }

        return 0;
	}

	protected List<int[]> generateCandidateSizeK(List<int[]> levelK_1) {

		List<int[]> candidates = new ArrayList<int[]>();
		loop1: for (int i = 0; i < levelK_1.size(); i++) {
			int[] itemset1 = levelK_1.get(i);
			loop2: for (int j = i + 1; j < levelK_1.size(); j++) {
				int[] itemset2 = levelK_1.get(j);
				for (int k = 0; k < itemset1.length; k++) {
					if (k == itemset1.length - 1) {
						if (itemset1[k] >= itemset2[k]) {
							continue loop1;
						}
					} else if (itemset1[k] < itemset2[k]) {
						continue loop2;
					} else if (itemset1[k] > itemset2[k]) {
						continue loop1;
					}
				}

				int lastItem1 =  itemset1[itemset1.length -1];
				int lastItem2 =  itemset2[itemset2.length -1];
				int newItemset[];
				if (lastItem1 < lastItem2) {
					newItemset = new int[itemset1.length+1];
					System.arraycopy(itemset1, 0, newItemset, 0, itemset1.length);
					newItemset[itemset1.length] = lastItem2;
					candidates.add(newItemset);
				} else {
					newItemset  = new int[itemset1.length+1];
					System.arraycopy(itemset2, 0, newItemset, 0, itemset2.length);
					newItemset[itemset2.length] = lastItem1;
					candidates.add(newItemset);
				}
			}
		}
		return candidates; 
	}

	protected void saveRule(int[] itemset1, int supportItemset1, int[] itemset2, int absoluteSupport, double conf) {
		
		ruleCount++;
		rules.add(new AssocRule(itemset1, itemset2, supportItemset1, absoluteSupport, conf));

	}

}
