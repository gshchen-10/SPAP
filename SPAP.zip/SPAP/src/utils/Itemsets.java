package utils;

import java.util.ArrayList;
import java.util.List;

public class Itemsets {
	
	private final List<List<ItemArray>> levels = new ArrayList<List<ItemArray>>(); 
	private int itemsetsCount = 0;

	public Itemsets() {
		levels.add(new ArrayList<ItemArray>());
	}

	public void addItemset(ItemArray itemset, int k) {
		while (levels.size() <= k) {
			levels.add(new ArrayList<ItemArray>());
		}
		levels.get(k).add(itemset);
		itemsetsCount++;
	}

	public List<List<ItemArray>> getLevels() {
		return levels;
	}

	public int getItemsetsCount() {
		return itemsetsCount;
	}
	
	public void decreaseItemsetCount() {
		itemsetsCount--;
	}
	
}
