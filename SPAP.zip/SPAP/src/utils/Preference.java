package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Preference {	

	private Map<Integer, Integer> productFrequency;
	private Map<Integer, Float> productTendency; 
	
	public Preference() {
		productFrequency = new HashMap<>();
		productTendency = new HashMap<>();
	}
	
	public void addProduct(int prod, ArrayList<Integer> emb) {
		productFrequency.put(prod, emb.size());
		float tent = mean(emb);
		productTendency.put(prod, tent);
	}
	
	public ArrayList<Integer> totalOrderOfPreference() {
		
		ArrayList<Integer> prodPreferenceList = new ArrayList<>();
							
		List<Map.Entry<Integer, Integer>>  frequencyAfterSord = new ArrayList<Map.Entry<Integer, Integer>>(productFrequency.entrySet());		
		Collections.sort(frequencyAfterSord, new Comparator<Map.Entry<Integer, Integer>>() {
			public int compare(Map.Entry<Integer, Integer> o1, Map.Entry<Integer, Integer> o2) {
				return (o2.getValue().compareTo(o1.getValue()));
			}
		});
		
		ArrayList<Integer> sorted = new ArrayList<>();
		for (int i = 0; i < frequencyAfterSord.size() - 1; ) {
			Map<Integer, Float> tempMap = new HashMap<>();
			tempMap.put(frequencyAfterSord.get(i).getKey(), productTendency.get(frequencyAfterSord.get(i).getKey()));
			int j = i + 1;
			for (; j < frequencyAfterSord.size(); j++) {
				if (frequencyAfterSord.get(i).getValue().equals(frequencyAfterSord.get(j).getValue())) {
					tempMap.put(frequencyAfterSord.get(j).getKey(), productTendency.get(frequencyAfterSord.get(j).getKey()));
				} else
					break;
			}
			ArrayList<Integer> tempList = sortAccordingToTendency(tempMap);
			i = j;
			sorted.addAll(tempList);
		}
		int size = sorted.size();
		for (int i = 0; i < size; i++)
			prodPreferenceList.add(sorted.get(i));
		
		return prodPreferenceList;
		
	}
	private ArrayList<Integer> sortAccordingToTendency(Map<Integer, Float> tempMap) {
		
		List<Map.Entry<Integer, Float>>  tendencyAfterSord = new ArrayList<Map.Entry<Integer, Float>>(tempMap.entrySet());
		Collections.sort(tendencyAfterSord, new Comparator<Map.Entry<Integer, Float>>() {
			public int compare(Map.Entry<Integer, Float> o1, Map.Entry<Integer, Float> o2) {
				return (o2.getValue().compareTo(o1.getValue()));
			}
		});
		ArrayList<Integer> tempList = new ArrayList<>();
		for (int i = 0; i < tendencyAfterSord.size(); i++)
			tempList.add(tendencyAfterSord.get(i).getKey());
		
		return tempList;
	}
	
	private float mean(ArrayList<Integer> list) {
		float sum = 0.0f;
		for (int i = 0; i < list.size(); i++)
			sum += list.get(i);
		return sum / list.size();
	}

}
