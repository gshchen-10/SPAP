package utils;

public class AssociationRule {
	
	int antecedent;	
	int seccedent;	
	int support;	
	double confidence;
	
	public AssociationRule(int ant, int sec, int sup, double conf) {
		
		this.antecedent = ant;
		this.seccedent = sec;
		this.support = sup;
		this.confidence = conf;		
	}

}
