package utils;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ProductRanking {
	
	private Map<Integer, Float> productProbability = new HashMap<>();
	ArrayList<Integer> recommendedProductsList = new ArrayList<>();
	
	public ProductRanking() {
		
	}

	public Map<Integer, Float> getProdProb() {
		return productProbability;
	}
	
	public void addProductProbability(int item, float prob) {
		
		if (productProbability.get(item) == null) {
			productProbability.put(item, prob);		
		} else {
			float temp = productProbability.get(item);
			if (temp < prob) {
				productProbability.remove(item);
				productProbability.put(item, prob);
			}
		}
	}
	
	public void addAssociatedItem(int containedItem, int associatedItem, float confid) {
		
		if (productProbability.get(containedItem) == null)
			return;
		
		float associatedProb = productProbability.get(containedItem) * confid;
		if (productProbability.get(associatedItem) == null)
			productProbability.put(associatedItem, associatedProb);
		else {
			float temp = productProbability.get(associatedItem);
			if (temp < associatedProb) {
				productProbability.remove(associatedItem);
				productProbability.put(associatedItem, associatedProb);
			}
		}
	}
	
	public int sortAccordingToProbability() {
		
		List<Map.Entry<Integer, Float>>  afterSord = new ArrayList<Map.Entry<Integer, Float>>(productProbability.entrySet());
		Collections.sort(afterSord, new Comparator<Map.Entry<Integer, Float>>() {
			public int compare(Map.Entry<Integer, Float> o1, Map.Entry<Integer, Float> o2) {
				return (o2.getValue().compareTo(o1.getValue()));
			}
		});
		int size = afterSord.size();
		for (int i = 0; i < size; i++) {
			recommendedProductsList.add(afterSord.get(i).getKey());
		}
		
		return productProbability.size();
		
	}

}
