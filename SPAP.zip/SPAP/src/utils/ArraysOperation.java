package utils;

import java.util.Arrays;
import java.util.Comparator;

public class ArraysOperation {
	
	public static int[] cloneItemSetMinusOneItem(int[] itemset, Integer itemToRemove) {
		int[] newItemset = new int[itemset.length - 1];
		int i = 0;
		for (int j = 0; j < itemset.length; j++) {
			if (itemset[j] != itemToRemove) {
				newItemset[i++] = itemset[j];
			}
		}
		return newItemset;
	}
	
	public static int[] cloneItemSetMinusAnItemset(int[] itemset, int[] itemsetToNotKeep) {
		int[] newItemset = new int[itemset.length - itemsetToNotKeep.length];
		int i = 0;
		for (int j = 0; j < itemset.length; j++) {
			if (Arrays.binarySearch(itemsetToNotKeep, itemset[j]) < 0 ) {
				newItemset[i++] = itemset[j];
			}
		}
		return newItemset;
	}
	
	public static boolean allTheSameExceptLastItem(int[] itemset1, int[] itemset2) {
		for (int i = 0; i < itemset1.length - 1; i++) {
			if (itemset1[i] != itemset2[i]) {
				return false;
			}
		}
		return true;
	}
	
	public static int[] concatenate(int[] prefix, int[] suffix) {
		int[] concatenation = new int[prefix.length + suffix.length];
		System.arraycopy(prefix, 0, concatenation, 0, prefix.length);
		System.arraycopy(suffix, 0, concatenation, prefix.length, suffix.length);
		return concatenation;
	}
	
	public static int[] intersectTwoSortedArrays(int[] array1, int[] array2) {
		
	    final int newArraySize = (array1.length < array2.length) ? array1.length : array2.length;
	    int[] newArray = new int[newArraySize];
	    int pos1 = 0;
	    int pos2 = 0;
	    int posNewArray = 0;
	    while (pos1 < array1.length && pos2 < array2.length) {
	    	if (array1[pos1] < array2[pos2]) {
	    		pos1++;
	    	} else if (array2[pos2] < array1[pos1]) {
	    		pos2++;
	    	} else {
	    		newArray[posNewArray] = array1[pos1];
	    		posNewArray++;
	    		pos1++;
	    		pos2++;
	    	}
	    }
	    return Arrays.copyOfRange(newArray, 0, posNewArray); 
	}
	
	public static boolean containsOrEquals(Integer itemset1 [], Integer itemset2 []) {
		loop : for (int i = 0; i < itemset2.length; i++) {
			for (int j = 0; j < itemset1.length; j++) {
				if (itemset1[j].intValue() == itemset2[i].intValue()) {
					continue loop;
				} else if (itemset1[j].intValue() > itemset2[i].intValue()) {
					return false;
				}
			}
			return false;
		}
 		return true;
	}
	
	public static boolean containsLEX(Integer itemset[], Integer item, int maxItemInArray) {
		if (item > maxItemInArray) {
			return false;
		}
		for (Integer itemI : itemset) {
			if (itemI.equals(item)) {
				return true;
			}
			else if (itemI > item) {
				return false;
			}
		}
		return false;
	}
	
	public static int sameAs(int [] itemset1, int [] itemsets2, int posRemoved) {
		int j = 0;
		for (int i = 0; i < itemset1.length; i++) {
			if (j == posRemoved) {
				j++;
			}
			if (itemset1[i] == itemsets2[j]) {
				j++;
			} else if (itemset1[i] > itemsets2[j]) {
				return 1;
			} else {
				return -1;
			}
		}
		return 0;
	}
	
	public static boolean includedIn(int[] itemset1, int[] itemset2) {
		int count = 0;		
		for (int i = 0; i < itemset2.length; i++) {
			if (itemset2[i] == itemset1[count]) {
				count++;
				if (count == itemset1.length) {
					return true;
				}
			}
		}
		return false;
	}
	
	public static boolean includedIn(int[] itemset1, int itemset1Length, int[] itemset2) {
		int count = 0;		
		for (int i = 0; i < itemset2.length; i++) {
			if (itemset2[i] == itemset1[count]) {
				count++;
				if (count == itemset1Length) {
					return true;
				}
			}
		}
		return false;
	}
	
	public static boolean containsLEXPlus(int[] itemset, int item) {
		for (int i = 0; i < itemset.length; i++) {
			if (itemset[i] == item) {
				return true;
			} else if (itemset[i] > item) {
				return true;
			}
		}
		return false;
	}
	
	public static boolean containsLEX(int[] itemset, int item) {
		for (int i = 0; i < itemset.length; i++) {
			if (itemset[i] == item) {
				return true;
			} else if (itemset[i] > item) {
				return false;
			}
		}
		return false;
	}
	
	public static boolean contains(int[] itemset, int item) {
		for (int i = 0; i<itemset.length; i++) {
			if (itemset[i] == item) {
				return true;
			} else if (itemset[i] > item) {
				return false;
			}
		}
		return false;
	}

	public static Comparator<int[]> comparatorItemsetSameSize = new Comparator<int[]>() {
		@Override	
		public int compare(int[] itemset1, int[] itemset2) {
			for (int i = 0; i < itemset1.length; i++) {
				if (itemset1[i] < itemset2[i]) {
					return -1;
				} else if (itemset2[i] < itemset1[i]) {
					return 1;
				}
			}
			return 0;
		}
	};

	public static int[] appendIntegerToArray(int[] array, int integer) {
		int[] newgen = new int[array.length + 1];
		System.arraycopy(array, 0, newgen, 0, array.length);
		newgen[array.length] = integer;
		return newgen;
	}
	
	public static double[] convertStringArrayToDoubleArray(String[] tokens) {
		double[] numbers = new double[tokens.length];
		for (int i = 0; i <tokens.length; i++) {
			String token = tokens[i];
			numbers[i] = Double.parseDouble(token);
		}
		return numbers;
	}

}
