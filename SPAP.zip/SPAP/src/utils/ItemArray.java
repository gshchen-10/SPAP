package utils;

import java.util.Arrays;
import java.util.List;

public class ItemArray extends AbstractOrderedItemset {
	
	public int[] itemset;
	public int support = 0;
	
	public ItemArray() {
		itemset = new int[]{};
	}
	
	public ItemArray(int item) {
		itemset = new int[]{item};
	}

	public ItemArray(int[] items) {
		this.itemset = items;
	}
	
	public ItemArray(List<Integer> itemset, int support) {
		this.itemset = new int[itemset.size()];
	    int i = 0;
	    for (Integer item : itemset) { 
	    	this.itemset[i++] = item.intValue();
	    }
	    this.support = support;
	}
	
	public int[] getItems() {
		return itemset;
	}
	
	public int getAbsoluteSupport() {
		return support;
	}
	
	public int size() {
		return itemset.length;
	}

	public Integer get(int position) {
		return itemset[position];
	}

	public void setAbsoluteSupport(Integer support) {
		this.support = support;
	}

	public void increaseTransactionCount() {
		this.support++;
	}

	public ItemArray cloneItemSetMinusOneItem(Integer itemToRemove) {
		int[] newItemset = new int[itemset.length - 1];
		int i = 0;
		for (int j = 0; j < itemset.length; j++) {
			if (itemset[j] != itemToRemove) {
				newItemset[i++] = itemset[j];
			}
		}
		return new ItemArray(newItemset);
	}
	
	public ItemArray cloneItemSetMinusAnItemset(ItemArray itemsetToNotKeep) {
		int[] newItemset = new int[itemset.length - itemsetToNotKeep.size()];
		int i = 0;
		for (int j = 0; j < itemset.length; j++) {
			if (itemsetToNotKeep.contains(itemset[j]) == false) {
				newItemset[i++] = itemset[j];
			}
		}
		return new ItemArray(newItemset);
	}
	
	public ItemArray intersection(ItemArray itemset2) {
		int[] intersection = ArraysOperation.intersectTwoSortedArrays(this.getItems(), itemset2.getItems());
		return new ItemArray(intersection);
	}
	
	@Override
	public int hashCode() {		
		return Arrays.hashCode(itemset);
	}

}
