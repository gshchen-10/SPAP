package utils;

import java.util.ArrayList;
import java.util.List;

public class SequentialPatterns {
	
	private final List<List<SequentialPattern>> levels = new ArrayList<List<SequentialPattern>>(); 

	public int sequenceCount = 0;
	
	public SequentialPatterns() {
		levels.add(new ArrayList<SequentialPattern>()); 
	}

	public SequentialPatterns copy() {
		
		int k = 0;
		SequentialPatterns clone = new SequentialPatterns();
		for (List<SequentialPattern> level : this.getLevels()) {
			for (SequentialPattern pattern : level) 
				clone.addSequence(pattern.copy(), k);
			k++;
		}		
		return clone;
	}
	
	public void addSequence(SequentialPattern sequence, int k) {
		while (levels.size() <= k) {
			levels.add(new ArrayList<SequentialPattern>());
		}
		levels.get(k).add(sequence);
		sequenceCount++;
	}
	
	public List<SequentialPattern> getLevel(int index) {
		return levels.get(index);
	}
	
	public int getLevelsSize() {
		return levels.size();
	}
	
	public List<List<SequentialPattern>> getLevels() {
		return levels;
	}
	
	public int getSequenceCount() {
		return sequenceCount;
	}
	
}
