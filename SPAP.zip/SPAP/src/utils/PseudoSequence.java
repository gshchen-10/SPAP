package utils;

public class PseudoSequence {
	
	protected int sequenceID;	
	protected int indexFirstItem;
	
	public PseudoSequence(int sequenceID, int indexFirstItem){
		this.sequenceID = sequenceID;
		this.indexFirstItem = indexFirstItem;
	}

	public int getOriginalSequenceID() {
		return sequenceID;
	}

	public int getIndexFirstItem() {
		return indexFirstItem;
	}

	public int getSequenceID() {
		return sequenceID;
	}

}
