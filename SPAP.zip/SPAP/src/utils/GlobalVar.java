package utils;

public class GlobalVar {
	
	public static int minAbsoluteFrequency;	
	public static float minRelativeFrequency;
	public static float minConfidence;
	public static float coefficientOfVariation;
	public static int customerCount;	
	public static int recommendedItemCount;
			
	public static void setGlobalVar(float relatFreq, int freq, float minConfidence, int custcount, float coefOfVar) {
		GlobalVar.minRelativeFrequency = relatFreq;
		GlobalVar.minAbsoluteFrequency = freq;
		GlobalVar.minConfidence = minConfidence;
		GlobalVar.customerCount = custcount;
		GlobalVar.coefficientOfVariation = coefOfVar;
	}
	
}
