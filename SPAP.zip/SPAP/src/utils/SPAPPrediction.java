package utils;

import java.text.DecimalFormat;

public class SPAPPrediction {
	
	long startTimestamp = 0;
	long endTimestamp = 0;
	
	RetailDatabase retailDatabase;
	SeqVerticalDatabase seqVertDatabase;
	PredictionResult predictionResult;
	
	int assocRuleCount = 0;
	int seqRuleCount = 0;
	int periodicPatternCount = 0;
	int itemsFromPattPred = 0;
	int totalSelectedItems = 0;
	

	public SPAPPrediction(String inputFile, int minOrderCount) {
		retailDatabase = new RetailDatabase(inputFile);
		retailDatabase.Preprocessing(minOrderCount);
	}

	public void Running(float relatFreqForRule, float confidenceForRule, float coefficientOfVariation, int freqper) {
				
		MemoryLogger.getInstance().reset();
		MemoryLogger.getInstance().checkMemory();
		startTimestamp = System.currentTimeMillis();
		
		retailDatabase.getSequencesDatabase();
		int custCount = retailDatabase.getCustomersListSize();
		int absoluteFrequency = (int)Math.ceil(custCount * relatFreqForRule);
		if (absoluteFrequency == 0)
			absoluteFrequency = 1;
		GlobalVar.setGlobalVar(relatFreqForRule, absoluteFrequency, confidenceForRule, custCount, coefficientOfVariation);

		seqVertDatabase = new SeqVerticalDatabase(retailDatabase);
		periodicPatternCount = seqVertDatabase.periodicPatternsMining(freqper);		
		seqRuleCount = seqVertDatabase.sequentialRulesMining();
		assocRuleCount = seqVertDatabase.associationRuleMining(relatFreqForRule, confidenceForRule);
		
		predictionResult = new PredictionResult(retailDatabase, seqVertDatabase);
		itemsFromPattPred = predictionResult.patternsPrediction();
		predictionResult.preferencePrediction();
		
		endTimestamp = System.currentTimeMillis();
		
		totalSelectedItems = predictionResult.calculateMeasures(retailDatabase.testSet);
		
	}
	
	public void printStatistics(String dataset) {
		DecimalFormat df =new DecimalFormat("#0.0000");		
		StringBuilder r = new StringBuilder(200);	
		/*
		r.append("======= RetailDataMiner - On Dataset: " + dataset + " =======\n");
		r.append("Sequence Count: " + GlobalVar.customerCount);
		r.append('\n');  

		r.append("Max OrderList Length: " + Customer.MaxOrderListLength);
		r.append('\n');
		r.append("min Absolute Support: " + GlobalVar.minAbsoluteSupport);
		r.append('\n');  
		r.append("Pattern count: " + seqVertDatabase.patternCount);
		r.append('\n');		
		
		
		r.append("Periodic Pattern Count: " + periodicPatternCount);
		r.append('\n');
		r.append("Association Rule Count: " + assocRuleCount);
		r.append('\n'); 
		r.append("Sequential Rule Count: " + seqRuleCount);
		r.append('\n');
		r.append("Items Count From Pattern Prediction: " + itemsFromPattPred);
		r.append('\n'); 
		
		
		r.append("F1 score:  " + df.format(predictedResult.F1Score) + " ");
		r.append('\n');
		r.append("Recall: " + predictedResult.Recall);
		r.append('\n');
		r.append("Precison: " + predictedResult.Precison);
		r.append('\n');
		r.append("Hit ration: " + df.format(predictedResult.HitRatio) + " ");
		r.append('\n');
		r.append("Run time: ");
		r.append((endTimestamp - startTimestamp) / 1000f);		
		r.append(" s \n");
		r.append("Max memory (mb): " );
		r.append( MemoryLogger.getInstance().getMaxMemory());
		r.append('\n');		
		r.append("========================================================\n"); 
		*/

		r.append("F1-Score: " + df.format(predictionResult.F1Score) + "    Hit-Ration: " + df.format(predictionResult.HitRatio) + "    Weight: " + df.format((float)itemsFromPattPred / totalSelectedItems)+  "    #Periodic Patterns: " + periodicPatternCount +  "    #Rules: " + (assocRuleCount + seqRuleCount) +  "    Time: " + ((endTimestamp - startTimestamp) / 1000f));
	
		System.out.println(r.toString());		
	}

}


