package utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class RetailDatabase {
	
	private Map<String, Integer> customersToIndex = new HashMap<>();
	private List<Customer> customersList = new ArrayList<>();
	public Map<String, Order> testSet = new HashMap<>();
	
	public List<int[]> custProductSequence = new ArrayList<>();	

	public RetailDatabase(String inputfile) {
		LoadData(inputfile);
	}

	private void LoadData(String inputfile) {
		
		try {
			FileInputStream fin = new FileInputStream(new File(inputfile));
			BufferedReader in = new BufferedReader(new InputStreamReader(fin));
			String line = "";
			while ((line = in.readLine()) != null) {
				
				if (line.isEmpty() == true || line.startsWith("%") || line.charAt(0) == '@' || line.charAt(0) == '#')
					continue;
				if (line.length() == 0)
					continue;
				
				ArrayList<String> recordline = new ArrayList<>();
				StringTokenizer tokenizer = new StringTokenizer(line);
				while (tokenizer.hasMoreElements()) {
					recordline.add(tokenizer.nextToken());
				}
				AddCustomer(new Customer(recordline.get(0), recordline.get(1), recordline.get(2), Integer.parseInt(recordline.get(3))));
			}				
			in.close();
		}
		catch(IOException e) {
			e.printStackTrace();
		}		
		
	}

	private void AddCustomer(Customer customer) {
		if (customersToIndex.get(customer.customerId) == null) {
			customersToIndex.put(customer.customerId, customersList.size());
			customersList.add(customer);
		} else {
			int custIndex = customersToIndex.get(customer.customerId);
			customersList.get(custIndex).AddOrderList(customer.getCustomerOrderList());
		}
	}
	
	public List<Customer> getCustomersList() {
		return customersList;
	}
	
	public int getCustomersListSize() {
		return customersList.size();
	}

	public void Preprocessing(int minOrderCount) {
		
		for (int i = 0; i < customersList.size(); i++) {
			customersList.get(i).sortOrderByOrderDate();
		}
		
		Map<String, Integer> tempCustToInd = new HashMap<>();
		ArrayList<Customer> tempCustList = new ArrayList<>();
		int index = 0;
		for (int i = 0; i < customersList.size(); i++) {
			if (customersList.get(i).getCustOrderSeqSize() > minOrderCount) {
				tempCustToInd.put(customersList.get(i).customerId, index);
				tempCustList.add(customersList.get(i));
				index++;
			}
		}
		customersToIndex = tempCustToInd;
		customersList = tempCustList;
		
		for (int i = 0; i < customersList.size(); i++) {
			String custId = customersList.get(i).customerId;
			int orderSize = customersList.get(i).getCustOrderSeqSize();
			testSet.put(custId, customersList.get(i).getCustOrderSeq().get(orderSize - 1));
			customersList.get(i).getCustOrderSeq().remove(orderSize - 1);			
		}
		
	}
	
	public void getSequencesDatabase() {
		for (int i = 0; i < customersList.size(); i++) {
			custProductSequence.add(customersList.get(i).getOrderProductSequence());
		}		
	    
	}

}
