package utils;

public class AssocRule {
	
	private int[] antecedent;
	private int[] consequent;

	private int coverage;
	private int support;
	private double confidence;

	public AssocRule(int[] itemset1, int[] itemset2, int coverage, int sup, double confidence) {
		this.antecedent = itemset1;
		this.consequent = itemset2;
		this.coverage = coverage;
		this.support = sup;
		this.confidence = confidence;
	}

	public double getRelativeSupport(int databaseSize) {
		return ((double) support) / ((double) databaseSize);
	}

	public int getAbsoluteSupport() {
		return support;
	}

	public double getConfidence() {
		return confidence;
	}

	public int getCoverage() {
		return coverage;
	}

	public String toString() {
		StringBuilder buffer = new StringBuilder();
		for (int i = 0; i < antecedent.length; i++) {
			buffer.append(antecedent[i]);
			if (i != antecedent.length - 1) {
				buffer.append(" ");
			}
		}
		buffer.append(" ==> ");
		for (int i = 0; i < consequent.length; i++) {
			buffer.append(consequent[i]);
			buffer.append(" ");
		}
		buffer.append("confidence: ");
		buffer.append(confidence);
		return buffer.toString();
	}

	public int[] getAntecedent() {
		return antecedent;
	}

	public int[] getConsequent() {
		return consequent;
	}

}
