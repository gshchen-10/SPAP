package utils;

import java.util.List;

public class ItemsetPattern {
	
	public final ItemList itemset;
	private List<Integer> sequencesIds;
	
	public ItemsetPattern(ItemList its, List<Integer> seqid){
		this.itemset = its;
		this.sequencesIds = seqid;
	}
	
	public List<Integer> getSeqId() {
		return this.sequencesIds;
	}

}
