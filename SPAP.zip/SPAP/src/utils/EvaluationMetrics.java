package utils;

import java.util.List;

public class EvaluationMetrics {
	
	String customerId = "";	
	float custPrecision;
    float custRecall; 
    float custF1Score; 
    int custHit;
    
	public void evaluatePrediction(List<Integer> realBasket, List<Integer> predBasket) {
		custPrecision = precisionScore(realBasket, predBasket);
		custRecall = recallScore(realBasket, predBasket);
		custF1Score = f1Score();
		custHit = hitScore(realBasket, predBasket);
	}
	
	private float precisionScore(List<Integer> realBasket, List<Integer> predBasket) {
		
		if (predBasket.size() == 0)
			return 0.0f;
		
		int count = 0;
		for (int i = 0; i < realBasket.size(); i++)						
			if (contain(predBasket, realBasket.get(i)))
				count++;	

		return (float)count / (float)predBasket.size();
	}
	
	private float recallScore(List<Integer> realBasket, List<Integer> predBasket) {
		
		if (predBasket.size() == 0)
			return 0.0f;
		
		int count = 0;
		for (int i = 0; i < realBasket.size(); i++)
			if (contain(predBasket, realBasket.get(i)))
				count++;
		
		return (float)count / (float)realBasket.size();
	}
	
	private float f1Score() {
		
		if (custPrecision == 0.0f && custRecall == 0.0f)
			return 0.0f;		
		
		return (float)(2.0 * custPrecision * custRecall) / (custPrecision + custRecall);
	}
	
	private int hitScore(List<Integer> realBasket, List<Integer> predBasket) {
		
		int count = 0;	
		for (int i = 0; i < realBasket.size(); i++)						
			if (contain(predBasket, realBasket.get(i)))
				count++;
		if (count > 0)
			return 1;
		else
			return 0;
	}
	
	public boolean contain(List<Integer> itemlist, int item) {
		boolean flag = false;
		for (int i = 0; i < itemlist.size(); i++) {
			if (itemlist.get(i).equals(item))
				flag = true;
		}
		return flag;
	}

}
