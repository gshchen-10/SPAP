package utils;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class SequentialPattern implements Comparable<SequentialPattern> {
	
	public final List<ItemList> itemsets;
	private List<Integer> sequencesIds;

	public void setSequenceIDs(List<Integer> sequencesIds) {
		this.sequencesIds = sequencesIds;
	}

	public SequentialPattern(){
		itemsets = new ArrayList<ItemList>();
	}

	public String getRelativeSupportFormated(int sequencecount) {
		double relSupport = ((double)sequencesIds.size()) / ((double) sequencecount);
		DecimalFormat format = new DecimalFormat();
		format.setMinimumFractionDigits(0); 
		format.setMaximumFractionDigits(5); 
		return format.format(relSupport);
	}

	public int getAbsoluteSupport(){
		return sequencesIds.size();
	}

	public void addItemset(ItemList itemset) {
		itemsets.add(itemset);
	}

	public SequentialPattern copy() {
		SequentialPattern clone = new SequentialPattern();
		for (ItemList it : itemsets) {
			clone.addItemset(it.cloneItemSet());
		}

		clone.sequencesIds = new ArrayList<Integer>(this.sequencesIds);
		return clone;
	}

	public List<ItemList> getItemsets() {
		return itemsets;
	}

	public ItemList get(int index) {
		return itemsets.get(index);
	}

	public int size(){
		return itemsets.size();
	}
	
	public List<Integer> getSequenceIDs() {
		return sequencesIds;
	}

	@Override
	public int compareTo(SequentialPattern o) {
		if(o == this){
			return 0;
		}
		int compare = this.getAbsoluteSupport() - o.getAbsoluteSupport();
		if(compare !=0){
			return compare;
		}
		return this.hashCode() - o.hashCode();
	}
	
	public int getLastItem() {
		if (itemsets.get(itemsets.size() - 1) != null)
			return itemsets.get(itemsets.size() - 1).items.get(itemsets.get(itemsets.size() - 1).items.size() - 1);
		else
			return -1;
	}
	
	public int getFirstItem() {
		if (itemsets.get(0) != null)
			return itemsets.get(0).items.get(0);
		else 
			return -1;
	}

}
