package utils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class SequentialRule {
	
	int antecedent;	
	int seccedent;	
	int frequency;	
	double confidence;	
	double meanGap;
	private List<Integer> sequencesIds;
	
	public SequentialRule(int ant, int sec, int sup, double conf, List<Integer> seqIds) {
		
		this.antecedent = ant;
		this.seccedent = sec;
		this.frequency = sup;
		this.confidence = conf;	
		this.sequencesIds = seqIds;				
	}
	
	public SequentialRule(int ant, int sec, double mgap, double conf, List<Integer> seqIds) {	
		
		this.antecedent = ant;
		this.seccedent = sec;
		this.meanGap = mgap;
		this.confidence = conf;	
		this.sequencesIds = seqIds;
		this.frequency = seqIds.size();		
	}
	
	public List<Integer> getSequencesIds() {
		return sequencesIds;
	}
	
	public void calculParameter(Map<Integer, SeqVerticalBitList> seqVertBitList) {		

		List<Integer> minIntList = new ArrayList<>();
		for (int i = 0; i < sequencesIds.size(); i++) {
			int indexAntecedent = seqVertBitList.get(antecedent).getSupportSeqID().indexOf(sequencesIds.get(i));
			int indexSeccedent = seqVertBitList.get(seccedent).getSupportSeqID().indexOf(sequencesIds.get(i));	
			int minInt = minInterval(seqVertBitList.get(antecedent).getEmbeddings().get(indexAntecedent), seqVertBitList.get(seccedent).getEmbeddings().get(indexSeccedent));
			if (minInt > 0) {
				minIntList.add(minInt);
			}								
		} 		
		meanGap = meanImperative(minIntList);
	}	
	
	public int minInterval(List<Integer> list1, List<Integer> list2) {

		int minValue = Integer.MAX_VALUE;
		for (int i = 0, j = 0; i < list1.size() && j < list2.size();) {
			int vari = list2.get(j) - list1.get(i);
			if (vari <= 0)
				j++;
			else {
				if (minValue > vari)
					minValue = vari;
				i++;
			}				
		}
		if (minValue == Integer.MAX_VALUE)
			return 0;
		
		return minValue;
	}
		
	private double meanImperative(List<Integer> minIntList) {
		double average = 0.0;
		for (double p : minIntList) {
			average += p;
		}
		average /= minIntList.size(); 		
		return average;
	}

}