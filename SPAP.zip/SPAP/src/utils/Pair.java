package utils;

import java.util.ArrayList;
import java.util.List;

public class Pair {
	
	protected final int item;	
	private List<PseudoSequence> pseudoSequences = new ArrayList<PseudoSequence>();

	public Pair(Integer item) {
		this.item = item;
	}

	public boolean equals(Object object) {
		Pair pair = (Pair) object;
		return pair.item == this.item;
	}

	public int hashCode() {
		return item+"".hashCode();
	}

	public int getItem() {
		return item;
	}

	public int getCount() {
		return pseudoSequences.size();
	}		

	public List<PseudoSequence> getPseudoSequences() {
		return pseudoSequences;
	}

}
