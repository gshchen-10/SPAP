package utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.distribution.ExponentialDistribution;

public class PredictionResult {
	
	public Map<String, ProductRanking> custProductRank;
	RetailDatabase retailDatabase;
	SeqVerticalDatabase seqVertDatabase;
	
	int itemSelFromPattPred = 0;

	public double F1Score = 0;
	public double Precison = 0;
	public double Recall = 0;
	public double HitRatio = 0;

	PredictionResult(RetailDatabase retailData, SeqVerticalDatabase seqvert) {
		custProductRank = new HashMap<>();
		this.retailDatabase = retailData;
		this.seqVertDatabase = seqvert;
	}
	
	public int patternsPrediction() {
		
		for (int i = 0; i < seqVertDatabase.periodicItemList.size(); i++) {
			String custID = seqVertDatabase.periodicItemList.get(i).custId;
			custProductRank.putIfAbsent(custID, new ProductRanking());
			custProductRank.get(custID).addProductProbability(seqVertDatabase.periodicItemList.get(i).item, seqVertDatabase.periodicItemList.get(i).probability);
		}
		
		for (int i = 0; i < seqVertDatabase.sequentialRulesList.size(); i++) {
			int curItem = seqVertDatabase.sequentialRulesList.get(i).antecedent;
			int nextItem = seqVertDatabase.sequentialRulesList.get(i).seccedent;
			float meanGap = (float) seqVertDatabase.sequentialRulesList.get(i).meanGap;
			for (int j = 0; j < seqVertDatabase.seqVertBitList.get(curItem).getEmbeddingsSize(); j++) {
				int embedingSize = seqVertDatabase.seqVertBitList.get(curItem).getEmbeddings().get(j).size();
				int lastOcurr = seqVertDatabase.seqVertBitList.get(curItem).getEmbeddings().get(j).get(embedingSize - 1);
				int seqId = seqVertDatabase.seqVertBitList.get(curItem).getSupportSeqID().get(j);
				String custId = retailDatabase.getCustomersList().get(seqId).customerId;
				int orderSeqLength = retailDatabase.getCustomersList().get(seqId).getCustOrderSeqSize();
				ExponentialDistribution dis = new ExponentialDistribution(meanGap);
				float prob = (float) dis.probability((orderSeqLength - lastOcurr) + 0.5, (orderSeqLength - lastOcurr) + 1.5);
				if (custProductRank.get(custId) == null) {
					custProductRank.put(custId, new ProductRanking());
					custProductRank.get(custId).addProductProbability(nextItem, prob);
				}
			}
		}
		
		for (Entry<String, ProductRanking> entry : custProductRank.entrySet()) {
			String cust = entry.getKey();
			if (seqVertDatabase.customeAssocRules.get(cust) != null) {
				for (int i = 0; i < seqVertDatabase.customeAssocRules.get(cust).size(); i++) {
					AssociationRule assRule = seqVertDatabase.customeAssocRules.get(cust).get(i);
					int curItem = assRule.antecedent;
					int associatedItem = assRule.seccedent;
					float conf = (float) assRule.confidence;
					entry.getValue().addAssociatedItem(curItem, associatedItem, conf);					
				}
			}
		}
		
		for (Entry<String, ProductRanking> entry : custProductRank.entrySet()) {
			int count = custProductRank.get(entry.getKey()).sortAccordingToProbability();
			if (count > GlobalVar.recommendedItemCount)
				itemSelFromPattPred += GlobalVar.recommendedItemCount;
			else
				itemSelFromPattPred += count;
		}
		
		return itemSelFromPattPred;
		
	}
	
	public void preferencePrediction() {
		
		for (int i = 0; i < retailDatabase.getCustomersListSize(); i++) {
			String cust = retailDatabase.getCustomersList().get(i).customerId;
			if (custProductRank.get(cust) == null) {
				custProductRank.put(cust, new ProductRanking());
				custProductRank.get(cust).recommendedProductsList = seqVertDatabase.custProdPreference.get(cust).totalOrderOfPreference();
			} else if (custProductRank.get(cust).recommendedProductsList.size() < GlobalVar.recommendedItemCount) {
				List<Integer> newRecommendedItem = seqVertDatabase.custProdPreference.get(cust).totalOrderOfPreference();
				for (int j = 0; j < newRecommendedItem.size(); j++)
					if (custProductRank.get(cust).getProdProb().get(newRecommendedItem.get(j)) == null)
						custProductRank.get(cust).recommendedProductsList.add(newRecommendedItem.get(j));
			}
		}
	}
	
	public int calculateMeasures(Map<String, Order> mapTran) {
		
		int totalSelectedItems = 0;
		
		List<EvaluationMetrics> allCustomers = new ArrayList<>();
		for (Entry<String, Order> entry : mapTran.entrySet()) {
			String custId = entry.getKey();
			if (custProductRank.get(custId) == null)
				continue;
			
			List<Integer> predBasket = new ArrayList<>();
			int recomListSize = custProductRank.get(custId).recommendedProductsList.size(); 
			int recomCount =  GlobalVar.recommendedItemCount > recomListSize ? recomListSize : GlobalVar.recommendedItemCount; 	
			totalSelectedItems += recomCount;
			for (int i = 0; i < recomCount; i++)
				predBasket.add(custProductRank.get(custId).recommendedProductsList.get(i));
			List<Integer> realBasket = entry.getValue().getOrdProductsList();
			EvaluationMetrics predresult = new EvaluationMetrics();
			predresult.customerId = custId;
			predresult.evaluatePrediction(realBasket, predBasket);
			allCustomers.add(predresult);			
		}
		
		float f1ScoreAll = 0.0f;
		int hitCount = 0;
		for (int i = 0; i < allCustomers.size(); i++) {
			f1ScoreAll += allCustomers.get(i).custF1Score;
			hitCount += allCustomers.get(i).custHit;
		}
		F1Score = f1ScoreAll / allCustomers.size();
		HitRatio = (float)hitCount / allCustomers.size();
		
		return totalSelectedItems;
	}

}
