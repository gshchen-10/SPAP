package utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.math3.distribution.NormalDistribution;

public class SeqVerticalDatabase {
	
	public Map<Integer, SeqVerticalBitList> seqVertBitList = new HashMap<>();		
	public RetailDatabase retailData = null;
	public Map<String, Preference> custProdPreference = new HashMap<>(); 
	public List<PeriodicItem> periodicItemList;
	public List<SequentialRule> sequentialRulesList;
	public List<AssociationRule> associationRulesList;
	public Map<String, List<AssociationRule>> customeAssocRules = new HashMap<>();
	
	SequentialPatterns patternsLists = null;
	public int patternCount;
	
	boolean multipleItems = false;
	final int BUFFERS_SIZE = 2000;
	private int[] patternBuffer = new int[BUFFERS_SIZE];	
	private int maximumPatternLength = 1000;

	public SeqVerticalDatabase(RetailDatabase database) {
		
		this.retailData = database;
		periodicItemList = new ArrayList<>();
		sequentialRulesList = new ArrayList<>();
		associationRulesList = new ArrayList<>();
		
		for (int i = 0; i < GlobalVar.customerCount; i++) {
			int prodId, k = 0, j = 0;
			int m = 0;
			for (; k < retailData.custProductSequence.get(i).length - 1; k++) {
				prodId = retailData.custProductSequence.get(i)[k];
				if (prodId != -1 && prodId != -2) {
					seqVertBitList.putIfAbsent(prodId, new SeqVerticalBitList());
					seqVertBitList.get(prodId).setEmbedding(i, j);
					m++;
				} else if (prodId == -1 && retailData.custProductSequence.get(i)[k + 1] != -2) {
					j++;
					if (m > 1)
						multipleItems = true;
					m = 0;
				} else {
					if (m > 1)
						multipleItems = true;
					m = 0;
				}
			}			
		}
	}
	
	public int periodicPatternsMining(int freqForPeriodicPattern) {
		
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertBitList.entrySet()) {
			int item = entry.getKey();
			int seqId = 0;
			for (int i = 0 ; i < seqVertBitList.get(item).getEmbeddingsSize(); i++) {
				ArrayList<Integer> embeds = seqVertBitList.get(item).getEmbeddings().get(i);
				seqId = seqVertBitList.get(item).getSupportSeqID().get(i);
				Customer customer = retailData.getCustomersList().get(seqId);
				String custID = customer.customerId;
				custProdPreference.putIfAbsent(custID, new Preference());
				custProdPreference.get(custID).addProduct(item, embeds);
				if (embeds.size() > freqForPeriodicPattern) {
					tryToGenPeriodicPattern(customer, item, embeds);
				}
			}
		}
		return periodicItemList.size();
	}
	
	private void tryToGenPeriodicPattern(Customer customer, int item, ArrayList<Integer> embeds) {
		
		List<Integer> embInterval = new ArrayList<>();
		int n = 0;
		for (; n < embeds.size() - 1; n++)
			embInterval.add(embeds.get(n + 1) - embeds.get(n));
		int cur = customer.getCustOrderSeqSize() - (embeds.get(n) + 1);
		double mean = meanImperative(embInterval);
		double vari = varianceImperative(embInterval, mean);
		double standvari = Math.sqrt(vari);
		if (standvari/mean < GlobalVar.coefficientOfVariation) {
			float prob = 0;
			if (standvari != 0) {
				NormalDistribution dis = new NormalDistribution(mean, standvari);
				prob = (float) dis.probability(cur - 0.5, cur + 0.5);
			} else
				if ((cur - mean) >= -0.5f && (cur - mean) <= 0.5f)
					prob = 1.0f;
			PeriodicItem periodic = new PeriodicItem(customer.customerId, item, (float)mean , (float)standvari, prob);
			periodicItemList.add(periodic);
		}
	}
	
	public int associationRuleMining(float relativeFrequency, float minConfidence) {		
		
		for (int i = 0; i < retailData.getCustomersListSize(); i++) {
			int databaseSize = retailData.getCustomersList().get(i).getCustOrderSeqSize();
			String custId = retailData.getCustomersList().get(i).customerId;
			FPGrowth fpgrowth = new FPGrowth(retailData.getCustomersList().get(i));
			int absoluteFrequency = (int)Math.ceil(databaseSize * relativeFrequency);
			if (absoluteFrequency == 0)
				absoluteFrequency = 1;
			Itemsets patterns = fpgrowth.itemsetPatternsMining(databaseSize, absoluteFrequency);			
			AssociationRuleGen associationRuleGen = new AssociationRuleGen();
			List<AssocRule> rules = associationRuleGen.tryToGenRule(patterns, databaseSize, minConfidence);
			if (rules.size() > 0) {
				List<AssociationRule> custAssocRuleList = new ArrayList<>();
				for(int j = 0; j < rules.size(); j++) {
					int ante = rules.get(j).getAntecedent()[0];
					int secc = rules.get(j).getConsequent()[0];
					AssociationRule assocRule = new AssociationRule(ante, secc, rules.get(j).getAbsoluteSupport(), rules.get(j).getConfidence());
					custAssocRuleList.add(assocRule);				
				}
				customeAssocRules.put(custId, custAssocRuleList);	
			}
		}
		
		int assocRuleCount = 0;
		return assocRuleCount;
			
	}
	
	public int sequentialRulesMining(float confidForAssoRule) {
		
		SequentialPatternsMining();
		retailData.custProductSequence = null;
		ArrayList<ItemsetPattern> itemsetPatternsList = new ArrayList<>();
		Map<Integer, Integer> frequentItems = new HashMap<>();
		
		if (patternsLists.getLevelsSize() > 1) {
			for (int j = 0; j < patternsLists.getLevel(1).size(); j++) {
				SequentialPattern pattern1 = patternsLists.getLevel(1).get(j);
				if (pattern1.itemsets.size() == 1) {
					if (pattern1.itemsets.get(0).size() > 1) {
						ItemsetPattern itsPat = new ItemsetPattern(pattern1.itemsets.get(0), pattern1.getSequenceIDs());
						itemsetPatternsList.add(itsPat);
					} else
						frequentItems.putIfAbsent(pattern1.itemsets.get(0).items.get(0), pattern1.getAbsoluteSupport());				
				}	
			}
		}		
		if (patternsLists.getLevelsSize() > 2) {
			for (int j = 0; j < patternsLists.getLevel(2).size(); j++) {
				SequentialPattern pattern1 = patternsLists.getLevel(2).get(j);
				if (pattern1.itemsets.size() == 2 && pattern1.itemsets.get(0).items.size() == 1 && pattern1.itemsets.get(1).items.size() == 1) {		
					tryToGenerateRule(pattern1, frequentItems, GlobalVar.minConfidence);
				}	
			}
		}
		patternsLists = null;
		
		for (int k = 0; k < itemsetPatternsList.size(); k++) {
			for (int m = 0; m < itemsetPatternsList.get(k).itemset.items.size(); m++) {
				int pattern1 = itemsetPatternsList.get(k).itemset.items.get(m);
				for (int n = m + 1; n < itemsetPatternsList.get(k).itemset.items.size(); n++) {
					int pattern2 = itemsetPatternsList.get(k).itemset.items.get(n);
					tryToGenerateRule(itemsetPatternsList.get(k), pattern1, pattern2, confidForAssoRule);
					tryToGenerateRule(itemsetPatternsList.get(k), pattern2, pattern1, confidForAssoRule);
				}
			}
		}

		itemsetPatternsList = null;
		return sequentialRulesList.size();
	}
	
	private void tryToGenerateRule(SequentialPattern pattern, Map<Integer, Integer> itemsFrequency, float minConfidence) {
		
		float conf = ((float) pattern.getAbsoluteSupport()) / itemsFrequency.get(pattern.get(0).items.get(0));
		if (conf < minConfidence) {
			return;
		}
		for (int i = 0; i < pattern.itemsets.get(1).items.size(); i++) {
			SequentialRule newsequencerule = new SequentialRule(pattern.get(0).items.get(0), pattern.itemsets.get(1).items.get(i), pattern.getAbsoluteSupport(), conf, pattern.getSequenceIDs());
			newsequencerule.calculParameter(seqVertBitList);
			sequentialRulesList.add(newsequencerule);
		}
	}
	
	private void tryToGenerateRule(ItemsetPattern itemsetPattern2, int pattern1, int pattern2, float minConfidence) {
		if (pattern1 == pattern2)
			return;

		float conf = ((float) itemsetPattern2.getSeqId().size()) / seqVertBitList.get(pattern1).getSupportSeqIDSize();
		
		if (conf < minConfidence) {
			return;
		}
		AssociationRule itrule = new AssociationRule(pattern1, pattern2, itemsetPattern2.getSeqId().size(), conf);
		associationRulesList.add(itrule);		
	}
	
	public void SequentialPatternsMining() {
		
		patternCount = 0;
		patternsLists = new SequentialPatterns();		
		
		if (multipleItems) {
			prefixspanWithMultipleItems();
		} else {
			prefixspanWithSingleItems();
		}
	}
	
	private void prefixspanWithMultipleItems() {
		
		List<int[]> compactDatabase = new ArrayList<>();
				
		for (int i = 0; i < retailData.custProductSequence.size(); i++) {
			compactDatabase.add(new int[1]);
			int[] sequence  = retailData.custProductSequence.get(i);
			int currentPosition = 0;
			int currentItemsetItemCount = 0;
			for (int j =0; j < sequence.length; j++) {
				int token = sequence[j];
				if (token > 0) {
					boolean isFrequent = seqVertBitList.get(token).getSupportSeqIDSize() >= GlobalVar.minAbsoluteFrequency;
					if (isFrequent) {
						sequence[currentPosition] = token;
						currentPosition++;
						currentItemsetItemCount++;
					}
				} else if (token == -1) {
					if (currentItemsetItemCount > 0) {
						sequence[currentPosition] = -1;
						currentPosition++;
						currentItemsetItemCount = 0;
					}
				} else if (token == -2) {
					if (currentPosition > 0) {
						sequence[currentPosition] = -2;
						int[] newSequence = new int[currentPosition + 1];
						System.arraycopy(sequence, 0, newSequence, 0, currentPosition + 1);
						compactDatabase.set(i, newSequence);
						continue; 
					} else {
						compactDatabase.set(i, null);
					}
				}
			}			
		}
				
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertBitList.entrySet()) {
			int support = entry.getValue().getSupportSeqIDSize();
			if (support >= GlobalVar.minAbsoluteFrequency) {
				int item = entry.getKey();
				savePattern(item, support, entry.getValue().getSupportSeqID());				
				if (maximumPatternLength > 1) {
					patternBuffer[0] = item;
					List<PseudoSequence> projectedDatabase  = buildProjectedDatabaseFirstTimeMultipleItems(compactDatabase, item, entry.getValue().getSupportSeqID());					
					recursion(compactDatabase, patternBuffer, projectedDatabase, 2, 0); 
				}
			}
		}		
	}
	
	private List<PseudoSequence> buildProjectedDatabaseFirstTimeMultipleItems(List<int[]> compactDatabase, int item, List<Integer> sequenceIDs) {
		
		List<PseudoSequence> projectedDatabase = new ArrayList<PseudoSequence>();
		for (int sequenceID : sequenceIDs) {
			int[] sequence = compactDatabase.get(sequenceID);
			for (int j = 0; sequence[j] != -2; j++) {
				int token = sequence[j];
				if (token == item) {
					boolean isEndOfSequence = sequence[j + 2] == -2;
					if (isEndOfSequence == false) {
						PseudoSequence pseudoSequence = new PseudoSequence(sequenceID, j + 1);
						projectedDatabase.add(pseudoSequence);
					}
					break;
				}
			}
		}		
		return projectedDatabase;
	}
	
	private void recursion(List<int[]> compactDatabase, int[] patternBuffer, List<PseudoSequence> database, int k, int lastBufferPosition) {
		
		if (k > 2)
			return;
		
		MapFrequentPairs mapsPairs = findAllFrequentPairs(compactDatabase, database, lastBufferPosition);
		database = null;		
		for (Entry<Pair,Pair> entry : mapsPairs.mapPairsInPostfix.entrySet()) {
			Pair pair = entry.getKey();
			if (pair.getCount() >= GlobalVar.minAbsoluteFrequency) {
				int newBuferPosition = lastBufferPosition;
				newBuferPosition++;
				patternBuffer[newBuferPosition] = pair.item;				
				savePattern(newBuferPosition, pair.getPseudoSequences());				
				if (k < maximumPatternLength) {
					recursion(compactDatabase, patternBuffer, pair.getPseudoSequences(), k+1, newBuferPosition);
				}
			}
		}		
		
		for (Entry<Pair,Pair> entry : mapsPairs.mapPairs.entrySet()) {
			Pair pair = entry.getKey();
			if(pair.getCount() >= GlobalVar.minAbsoluteFrequency) {
				int newBuferPosition = lastBufferPosition;
				newBuferPosition++;
				patternBuffer[newBuferPosition] = -1;
				newBuferPosition++;
				patternBuffer[newBuferPosition] = pair.item;				
				savePattern(newBuferPosition, pair.getPseudoSequences());				
				if (k < maximumPatternLength) {
					recursion(compactDatabase, patternBuffer, pair.getPseudoSequences(), k+1, newBuferPosition);
				}
			}
		}
		patternBuffer = null;		
	}
	
	protected MapFrequentPairs findAllFrequentPairs(List<int[]> compactDatabase, List<PseudoSequence> sequences, int lastBufferPosition) {
		
		MapFrequentPairs mapsPairs = new MapFrequentPairs();		
		int firstPositionOfLastItemsetInBuffer = lastBufferPosition;
		while (lastBufferPosition > 0) {
			firstPositionOfLastItemsetInBuffer--;
			if (firstPositionOfLastItemsetInBuffer < 0 || patternBuffer[firstPositionOfLastItemsetInBuffer] == -1) {
				firstPositionOfLastItemsetInBuffer++;
				break;
			}
		}
		
		int positionToBeMatched = firstPositionOfLastItemsetInBuffer;
		for (PseudoSequence pseudoSequence : sequences) {
			int sequenceID = pseudoSequence.getOriginalSequenceID();
			int[] sequence = compactDatabase.get(sequenceID);
			int previousItem = sequence[pseudoSequence.indexFirstItem - 1];
			boolean currentItemsetIsPostfix = (previousItem != - 1);
			boolean isFirstItemset = true;
			for (int i = pseudoSequence.indexFirstItem; sequence[i] != -2; i++) {
				int token = sequence[i];
				if (token > 0) {
					Pair pair = new Pair(token);
					Pair oldPair;
					if (currentItemsetIsPostfix) {
						oldPair = mapsPairs.mapPairsInPostfix.get(pair);
					} else {
						oldPair = mapsPairs.mapPairs.get(pair);
					}
					if (oldPair == null) {
						if (currentItemsetIsPostfix) {
							mapsPairs.mapPairsInPostfix.put(pair, pair);
						} else {
							mapsPairs.mapPairs.put(pair, pair);
						}
					} else {
						pair = oldPair;
					}
					boolean ok = true;
					if (pair.getPseudoSequences().size() > 0) {
						ok = pair.getPseudoSequences().get(pair.getPseudoSequences().size() - 1).sequenceID != sequenceID;
					}					
					if (ok) {
						pair.getPseudoSequences().add(new PseudoSequence(sequenceID, i + 1));
					}					
					if (currentItemsetIsPostfix && isFirstItemset == false) {
						pair = new Pair(token); 
						oldPair = mapsPairs.mapPairs.get(pair);
						if (oldPair == null) {
							mapsPairs.mapPairs.put(pair, pair);
						} else {
							pair = oldPair;
						}						 
						ok = true;
						if (pair.getPseudoSequences().size() > 0) {
							ok = pair.getPseudoSequences().get(pair.getPseudoSequences().size() - 1).sequenceID != sequenceID;
						}
						if (ok) {
							pair.getPseudoSequences().add(new PseudoSequence(sequenceID, i+1));
						}
					}					
					if (currentItemsetIsPostfix == false && patternBuffer[positionToBeMatched] == token) {
						 positionToBeMatched++;
						 if (positionToBeMatched > lastBufferPosition) {
							 currentItemsetIsPostfix = true;
						 }
					 }
				} else if (token == -1) {
					isFirstItemset = false;
					currentItemsetIsPostfix = false;
					positionToBeMatched = firstPositionOfLastItemsetInBuffer;
				}
			}
		}
		return mapsPairs;
	}
	
	private void prefixspanWithSingleItems() {
		
		List<int[]> compactDatabase = new ArrayList<>();
		
		for (int i = 0; i < retailData.custProductSequence.size(); i++) {
			compactDatabase.add(new int[0]);
			int[] sequence  = retailData.custProductSequence.get(i);
			int currentPosition = 0;
			for (int j = 0; j < sequence.length; j++) {
				int token = sequence[j];
				if (token > 0) {
					boolean isFrequent = seqVertBitList.get(token).getSupportSeqIDSize() >= GlobalVar.minAbsoluteFrequency;
					if(isFrequent) {
						sequence[currentPosition] = token;
						currentPosition++;
					}
				} else if (token == -2) {
					if (currentPosition > 0) {
						sequence[currentPosition] = -2;
						int[] newSequence = new int[currentPosition+1];
						System.arraycopy(sequence, 0, newSequence, 0, currentPosition+1);
						compactDatabase.set(i, newSequence);
						continue; 
					} else
						compactDatabase.set(i, null); 
				}
			}		
		}
		
		for (Entry<Integer, SeqVerticalBitList> entry : seqVertBitList.entrySet()) {
			int support = entry.getValue().getSupportSeqIDSize();
			if (support >= GlobalVar.minAbsoluteFrequency) {
				int item = entry.getKey();
				savePattern(item, support, entry.getValue().getSupportSeqID());
				if (maximumPatternLength > 1) {
					patternBuffer[0] = item;
					List<PseudoSequence> projectedDatabase = buildProjectedDatabaseSingleItems(compactDatabase, item, entry.getValue().getSupportSeqID());
					recursionSingleItems(compactDatabase, projectedDatabase, 2, 0);
				}
			}
		}		
	}
	
	private void recursionSingleItems(List<int[]> compactDatabase, List<utils.PseudoSequence> database, int k, int lastBufferPosition) {
		
		if (k > 2)
			return;
		
		Map<Integer,List<PseudoSequence>> itemsPseudoSequences = findAllFrequentPairsSingleItems(compactDatabase, database, lastBufferPosition);
		database = null;
		for (Entry<Integer, List<PseudoSequence>> entry : itemsPseudoSequences.entrySet()) {
			if (entry.getValue().size() >= GlobalVar.minAbsoluteFrequency) {				
				patternBuffer[lastBufferPosition+1] = -1;
				patternBuffer[lastBufferPosition+2] = entry.getKey();
				savePattern(lastBufferPosition + 2, entry.getValue());
				if (k < maximumPatternLength) {
					recursionSingleItems(compactDatabase, entry.getValue(), k + 1, lastBufferPosition + 2);
				}
			}
		}		
	}
	
	private Map<Integer, List<utils.PseudoSequence>> findAllFrequentPairsSingleItems(List<int[]> compactDatabase, List<utils.PseudoSequence> sequences,	int lastBufferPosition) {
		
		Map<Integer, List<PseudoSequence>>  mapItemsPseudoSequences = new HashMap<Integer, List<PseudoSequence>>();
		for (PseudoSequence pseudoSequence : sequences) {
			int sequenceID = pseudoSequence.getOriginalSequenceID();
			int[] sequence = compactDatabase.get(sequenceID);
			for (int i = pseudoSequence.indexFirstItem; sequence[i] != -2; i++) {
				int token = sequence[i];
				if (token > 0) {
					List<PseudoSequence> listSequences = mapItemsPseudoSequences.get(token);
					if (listSequences == null) {
						listSequences = new ArrayList<PseudoSequence>();
						mapItemsPseudoSequences.put(token, listSequences);
					}					
					boolean ok = true;
					if (listSequences.size() > 0) {
						ok = listSequences.get(listSequences.size() - 1).sequenceID != sequenceID;
					}
					if (ok) {
						listSequences.add(new PseudoSequence(sequenceID, i + 1));
					}
				}
			}
		}
		return mapItemsPseudoSequences;
	}	
	
	private List<PseudoSequence> buildProjectedDatabaseSingleItems(List<int[]> compactDatabase, int item, List<Integer> sequenceIDs) {
		List<PseudoSequence> projectedDatabase = new ArrayList<PseudoSequence>();
		loopSeq: for (int sequenceID : sequenceIDs) { 
			int[] sequence = compactDatabase.get(sequenceID);
			for (int j = 0; sequence[j] != -2; j++) {
				int token = sequence[j];
				if (token == item) {
					if (sequence[j + 1] != -2) {
						PseudoSequence pseudoSequence = new PseudoSequence(sequenceID, j + 1);
						projectedDatabase.add(pseudoSequence);
					}
					continue loopSeq;
				}
			}
		}		
		return projectedDatabase;
	}
	
	private void savePattern(int lastBufferPosition, List<PseudoSequence> pseudoSequences) {
		patternCount++;
		SequentialPattern pattern = new SequentialPattern();
		int itemsetCount = 0;
		ItemList currentItemset = new ItemList();
		for (int i = 0; i <= lastBufferPosition; i++) {
			int token = patternBuffer[i];
			if (token > 0) {
				currentItemset.addItem(token);
			} else if (token == -1) {
				pattern.addItemset(currentItemset);
				currentItemset = new ItemList();
				itemsetCount++;
			}
		}
		pattern.addItemset(currentItemset);
		itemsetCount++;
		
		List<Integer> sequencesIDs = new ArrayList<Integer>(pseudoSequences.size());
		for (int i = 0; i < pseudoSequences.size(); i++) {
			sequencesIDs.add(pseudoSequences.get(i).sequenceID);
    	}
		pattern.setSequenceIDs(sequencesIDs);
		patternsLists.addSequence(pattern, itemsetCount);		
	}
	
	private void savePattern(int item, int support, List<Integer> sequenceIDs) {
		patternCount++; 
		SequentialPattern pattern = new SequentialPattern();
		pattern.addItemset(new ItemList(item));
		pattern.setSequenceIDs(sequenceIDs);
		patternsLists.addSequence(pattern, 1);
	}
	
	private class MapFrequentPairs{
	    public final Map<Pair, Pair> mapPairs = new HashMap<Pair, Pair>();
	    public final Map<Pair, Pair> mapPairsInPostfix = new HashMap<Pair, Pair>();
	};

	private double meanImperative(List<Integer> population) {
		double average = 0.0;
		for (double p : population) {
			average += p;
		}
		average /= population.size(); 		
		return average;
	}
	
	private double varianceImperative(List<Integer> population, double ave) {
		double average = ave; 
		double variance = 0.0;
		for (double p : population) {
			variance += (p - average) * (p - average);
		}
		return variance / population.size();
	}

}
