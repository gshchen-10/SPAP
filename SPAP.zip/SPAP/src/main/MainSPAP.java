package main;

import utils.SPAPPrediction;
import utils.GlobalVar;

public class MainSPAP {

	public static void main(String[] args)  {
		
		String dataset = "tmall";   // tafeng  coop100  tmall
		
		String inputPath = ".\\data\\" + dataset + ".txt";
		
		float relatFreqForSeqRule = 0.5f;
		float confidenceForSeqRule = 0.59f;
		float relatFreqForAssoRule = 0.3f;
		float confidenceForAssoRule = 0.1f;
		float coefficientOfVariation = 0.5f;
		int freqForPeriodicPattern = 5;
		
		int recommendedItemsNumber = 5;
		
		if (dataset.equals("tafeng")) {

			relatFreqForSeqRule = 0.045f;
			confidenceForSeqRule = 0.1f;
			relatFreqForAssoRule = 0.5f;
			confidenceForAssoRule = 0.05f;
			coefficientOfVariation = 0.4f;
			freqForPeriodicPattern = 5;

			recommendedItemsNumber = 6;
			
		} else if (dataset.equals("tmall")) {
			
			relatFreqForSeqRule = 0.014f;
			confidenceForSeqRule = 0.8f;
			relatFreqForAssoRule = 0.037f;
			confidenceForAssoRule = 0.5f;
			coefficientOfVariation = 0.25f;
			freqForPeriodicPattern = 5;
			
			recommendedItemsNumber = 3;
			
		} else if (dataset.equals("coop100")) {
			
			relatFreqForSeqRule = 0.98f;
			confidenceForSeqRule = 0.98f;
			relatFreqForAssoRule = 0.9f;
			confidenceForAssoRule = 0.5f;
			coefficientOfVariation = 2.8f;
			freqForPeriodicPattern = 5;
			
			recommendedItemsNumber = 9;
			
		} else {
			System.out.println("Unknow dataset!");
			return;
		}

		GlobalVar.recommendedItemCount = recommendedItemsNumber;
		SPAPPrediction spapPrediction = new SPAPPrediction(inputPath, dataset);		
		spapPrediction.Running(relatFreqForSeqRule, confidenceForSeqRule, relatFreqForAssoRule, confidenceForAssoRule, coefficientOfVariation, freqForPeriodicPattern);
		spapPrediction.printStatistics(dataset);
						
	}

}
