package main;

import utils.SPAPPrediction;

import utils.GlobalVar;

public class MainSPAP {

	public static void main(String[] args)  {
		
		String dataset = "tafeng";  
		
		String inputPath = ".\\data\\" + dataset + ".txt";

		float relatFreqForRule = 0.5f;
		float confidenceForRule = 0.59f;
		float coefficientOfVariation = 0.5f;
		int freqForPeriodicPattern = 5;
		
		int recommendedItemsNumber = 5;
		
		if (dataset.equals("tafeng")) {

			relatFreqForRule = 0.16f;
			confidenceForRule = 0.2f;
			coefficientOfVariation = 0.2f;
			freqForPeriodicPattern = 5;

			recommendedItemsNumber = 6;
			
		} else if (dataset.equals("tmall")) {
			
			relatFreqForRule = 0.1f;
			confidenceForRule = 0.8f;
			coefficientOfVariation = 0.8f;
			freqForPeriodicPattern = 8;
			
			recommendedItemsNumber = 3;
			
		} else if (dataset.equals("x5retailhero")) {
			
			relatFreqForRule = 0.12f;
			confidenceForRule = 0.6f;
			coefficientOfVariation = 0.8f;
			freqForPeriodicPattern = 10;
			
			recommendedItemsNumber = 5;
			
		} else if (dataset.equals("Dunnhumby")) {
			
			relatFreqForRule = 0.35f;
			confidenceForRule = 0.7f;
			coefficientOfVariation = 2.2f;
			freqForPeriodicPattern = 12;
			
			recommendedItemsNumber = 9;
			
		} else {
			System.out.println("Unknow dataset!");
			return;
		}
		
		GlobalVar.recommendedItemCount = recommendedItemsNumber;
		SPAPPrediction spapPrediction = new SPAPPrediction(inputPath);
		spapPrediction.Running(relatFreqForRule, confidenceForRule, coefficientOfVariation, freqForPeriodicPattern);
		spapPrediction.printStatistics(dataset);
		
	}

}
